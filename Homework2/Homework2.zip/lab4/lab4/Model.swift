//
//  Model.swift
//  lab4
//
//  Created by Deven Pile on 3/4/21.
//

import Foundation
import CoreData

